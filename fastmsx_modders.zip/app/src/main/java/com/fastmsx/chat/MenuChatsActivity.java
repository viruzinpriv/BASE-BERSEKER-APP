package com.fastmsx.chat;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.cyberalpha.darkIOS.*;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.shashank.sony.fancytoastlib.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class MenuChatsActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	
	private ArrayList<String> listChat = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listchat = new ArrayList<>();
	private ArrayList<String> shidkey = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private Button button1;
	private Button metodos;
	private Button bots;
	private Button apps;
	private Button imunes;
	private Button divu;
	private Button button2;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_account;
	private LinearLayout _drawer_theme;
	private LinearLayout _drawer_grupos;
	private LinearLayout _drawer_linear10;
	private LinearLayout _drawer_linear12;
	private LinearLayout _drawer_linear15;
	private LinearLayout _drawer_linear14;
	private ImageView _drawer_imageview1;
	private LinearLayout _drawer_linear7;
	private TextView _drawer_textview1;
	private ImageView _drawer_imageview6;
	private ImageView _drawer_imageview2;
	private LinearLayout _drawer_linear8;
	private TextView _drawer_textview2;
	private ImageView _drawer_imageview7;
	private ImageView _drawer_imageview3;
	private LinearLayout _drawer_linear9;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview10;
	private ImageView _drawer_imageview11;
	private LinearLayout _drawer_linear11;
	private TextView _drawer_textview4;
	private ImageView _drawer_imageview12;
	private ImageView _drawer_imageview13;
	private LinearLayout _drawer_linear13;
	private Button _drawer_about;
	private Button _drawer_function;
	private ImageView _drawer_confi;
	
	private Intent intent = new Intent();
	private Intent about = new Intent();
	private AlertDialog.Builder ab;
	private Intent youtube = new Intent();
	private Intent gp = new Intent();
	private DatabaseReference Chat = _firebase.getReference("Chat");
	private ChildEventListener _Chat_child_listener;
	private Intent account = new Intent();
	private Intent beta = new Intent();
	private Intent version = new Intent();
	private Intent notification = new Intent();
	private AlertDialog.Builder Privacy;
	private Intent premium = new Intent();
	private Intent methods = new Intent();
	private Intent bot = new Intent();
	private Intent app = new Intent();
	private Intent imune = new Intent();
	private Intent youtub = new Intent();
	private SharedPreferences salvar;
	private AlertDialog.Builder aviso;
	private AlertDialog.Builder h;
	private Intent verificado = new Intent();
	private Intent config = new Intent();
	private AlertDialog.Builder dialog;
	private Intent midia = new Intent();
	private Intent aboutt = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.menu_chats);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MenuChatsActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		button1 = findViewById(R.id.button1);
		metodos = findViewById(R.id.metodos);
		bots = findViewById(R.id.bots);
		apps = findViewById(R.id.apps);
		imunes = findViewById(R.id.imunes);
		divu = findViewById(R.id.divu);
		button2 = findViewById(R.id.button2);
		_drawer_linear1 = _nav_view.findViewById(R.id.linear1);
		_drawer_account = _nav_view.findViewById(R.id.account);
		_drawer_theme = _nav_view.findViewById(R.id.theme);
		_drawer_grupos = _nav_view.findViewById(R.id.grupos);
		_drawer_linear10 = _nav_view.findViewById(R.id.linear10);
		_drawer_linear12 = _nav_view.findViewById(R.id.linear12);
		_drawer_linear15 = _nav_view.findViewById(R.id.linear15);
		_drawer_linear14 = _nav_view.findViewById(R.id.linear14);
		_drawer_imageview1 = _nav_view.findViewById(R.id.imageview1);
		_drawer_linear7 = _nav_view.findViewById(R.id.linear7);
		_drawer_textview1 = _nav_view.findViewById(R.id.textview1);
		_drawer_imageview6 = _nav_view.findViewById(R.id.imageview6);
		_drawer_imageview2 = _nav_view.findViewById(R.id.imageview2);
		_drawer_linear8 = _nav_view.findViewById(R.id.linear8);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_imageview7 = _nav_view.findViewById(R.id.imageview7);
		_drawer_imageview3 = _nav_view.findViewById(R.id.imageview3);
		_drawer_linear9 = _nav_view.findViewById(R.id.linear9);
		_drawer_textview3 = _nav_view.findViewById(R.id.textview3);
		_drawer_imageview10 = _nav_view.findViewById(R.id.imageview10);
		_drawer_imageview11 = _nav_view.findViewById(R.id.imageview11);
		_drawer_linear11 = _nav_view.findViewById(R.id.linear11);
		_drawer_textview4 = _nav_view.findViewById(R.id.textview4);
		_drawer_imageview12 = _nav_view.findViewById(R.id.imageview12);
		_drawer_imageview13 = _nav_view.findViewById(R.id.imageview13);
		_drawer_linear13 = _nav_view.findViewById(R.id.linear13);
		_drawer_about = _nav_view.findViewById(R.id.about);
		_drawer_function = _nav_view.findViewById(R.id.function);
		_drawer_confi = _nav_view.findViewById(R.id.confi);
		ab = new AlertDialog.Builder(this);
		Privacy = new AlertDialog.Builder(this);
		salvar = getSharedPreferences("salvar", Activity.MODE_PRIVATE);
		aviso = new AlertDialog.Builder(this);
		h = new AlertDialog.Builder(this);
		dialog = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				gp.setAction(Intent.ACTION_VIEW);
				gp.setClass(getApplicationContext(), ChatActivity.class);
				startActivity(gp);
			}
		});
		
		metodos.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				methods.setAction(Intent.ACTION_VIEW);
				methods.setClass(getApplicationContext(), MetodosActivity.class);
				startActivity(methods);
			}
		});
		
		bots.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				bot.setAction(Intent.ACTION_VIEW);
				bot.setClass(getApplicationContext(), BotsActivity.class);
				startActivity(bot);
			}
		});
		
		apps.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				app.setAction(Intent.ACTION_VIEW);
				app.setClass(getApplicationContext(), AppsActivity.class);
				startActivity(app);
			}
		});
		
		imunes.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				imune.setAction(Intent.ACTION_VIEW);
				imune.setClass(getApplicationContext(), ImunesActivity.class);
				startActivity(imune);
			}
		});
		
		divu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				youtub.setAction(Intent.ACTION_VIEW);
				youtub.setClass(getApplicationContext(), DivuActivity.class);
				startActivity(youtub);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				midia.setAction(Intent.ACTION_VIEW);
				midia.setClass(getApplicationContext(), MidiaActivity.class);
				startActivity(midia);
			}
		});
		
		_Chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Chat.addChildEventListener(_Chat_child_listener);
		
		_drawer_textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				account.setAction(Intent.ACTION_VIEW);
				account.setClass(getApplicationContext(), AccountActivity.class);
				startActivity(account);
				SketchwareUtil.showMessage(getApplicationContext(), "Account user");
			}
		});
		
		_drawer_textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				beta.setAction(Intent.ACTION_VIEW);
				beta.setClass(getApplicationContext(), BetaActivity.class);
				startActivity(beta);
				SketchwareUtil.showMessage(getApplicationContext(), "Beta user limited ");
			}
		});
		
		_drawer_textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				version.setAction(Intent.ACTION_VIEW);
				version.setClass(getApplicationContext(), VersionsActivity.class);
				startActivity(version);
				SketchwareUtil.showMessage(getApplicationContext(), "Versões anteriores");
			}
		});
		
		_drawer_textview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				h.setTitle("LEIA-ME");
				h.setMessage("PARA OBTER O ✓ NA SUA CONTA OU OBTER UMA CONTA VERIFICADA VOCÊ TERÁ QUE TER A CONTA ATIVA POR 1 MES E SEGUIR TODAS AS CONTAS VERIFICADAS EM SUAS REDES SOCIAIS PÚBLICAS.");
				h.setPositiveButton("obter verificado ", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						verificado.setClass(getApplicationContext(), VerifiActivity.class);
						startActivity(verificado);
					}
				});
				h.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				h.create().show();
			}
		});
		
		_drawer_about.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				aboutt.setAction(Intent.ACTION_VIEW);
				aboutt.setClass(getApplicationContext(), AboutActivity.class);
				startActivity(aboutt);
			}
		});
		
		_drawer_confi.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final AlertDialog dialog1 = new AlertDialog.Builder(MenuChatsActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.custom,null); 
				
				dialog.setView(inflate);
				
				
				
				Button but1 = (Button)inflate.findViewById(R.id.button1);
				
				
				but1.setOnClickListener(new OnClickListener() { public void onClick(View view) { _Test(); } });
				
				
				dialog.show();
				
				
				
				dialog.setCancelable(true);
			}
		});
	}
	
	private void initializeLogic() {
		if (salvar.getString("di", "").equals("1")) {
			
		}
		else {
			aviso.setTitle("⚠️ AVISO ⚠️");
			aviso.setMessage("OLÁ MEU NOBRE, NÃO ROUBE OS METODOS E NEM TENTE FAZER ENGENHARIA REVERSA JA QUE O APP ESTA CRIPTOGRAFADO NA DEX E PODE ATE PARAR DE FUNCIONAR 😀🤙🏻");
			aviso.setPositiveButton("okay", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					salvar.edit().putString("di", "1").commit();
				}
			});
			aviso.create().show();
		}
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)45, 0xFF424242));
		metodos.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)45, 0xFF424242));
		bots.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)45, 0xFF424242));
		apps.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)45, 0xFF424242));
		imunes.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)45, 0xFF424242));
		divu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)45, 0xFF424242));
		button2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)45, 0xFF424242));
		_Drawer_Transparent();
		ab = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK);
		Privacy = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK);
		aviso = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK);
		h = new AlertDialog.Builder(this,AlertDialog.THEME_DEVICE_DEFAULT_DARK);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		
		MenuItem mi = menu.add("Notifi");
		mi.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
		mi.setIcon(R.drawable.ic_notifications_grey);
		
		menu.add("Premium").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
		
		menu.add("Privacy Policy").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
		
		return true;
	}
	
	@Override 
	public boolean onOptionsItemSelected(final MenuItem item) {
		switch (item.getTitle().toString()) {
			
			case "Premium":
			_premiumClicked();
			return true;
			
			case "Privacy Policy":
			_privacyClicked();
			return true;
			
			case "Notifi":
			_rateClicked();
			return true;
			
			default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		} else {
			super.onBackPressed();
		}
	}
	public void _rateClicked() {
		notification.setAction(Intent.ACTION_VIEW);
		notification.setClass(getApplicationContext(), NotificacionsActivity.class);
		startActivity(notification);
	}
	
	
	public void _privacyClicked() {
		Privacy.setTitle("PRIVACY POLICY");
		Privacy.setIcon(R.drawable.ico_4);
		Privacy.setMessage("Viruzin  Created an FASTMSX CHAT App as an  App. This app was released by Viruzin  It is free of charge and is intended for use as is.\n\nThis page is used to inform users of this app about our policies and what information we collect if anyone decides to use our app.\n\nIf you choose to use this application, you agree to give us permission to collect and use information in connection with this policy. The personal information we collect is used to provide and improve the Service. We will not share your information with anyone except as described in this Privacy Policy.\n\nThe terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which can be accessed in Filak unless otherwise specified in this Privacy Policy.\n\nInformation collection and use\n\nFor a better experience, while using our Services, we may ask you to provide us with certain personally identifiable information.. The information we request from you will be kept on your device and we do not collect it in any way.\n\nThis app uses third party services that may collect some of your information that is used to identify you.\n\nBelow are links to the privacy policy of third party service providers used in this app:\n\nGoogle Play Services\nAdMob\n\n\nData recording\n\nWe want to inform you that when you use this app, in case of an error in the app, we collect data and information (through third party products) on your phone and this process is called data logging. This Log Data may include information such as your device's Internet Protocol (IP) address, device name, operating system version, the configuration of the Application when you use it, the time and date of your use of the Application, and other statistics.\n\nCookies\n\nCookies are files containing a small amount of data that are commonly used as anonymous unique identifiers. They are sent to your browser from the websites you visit and are stored on your device's internal memory.\nApplication FASTMSX CHAT It does not use \"cookies\" explicitly. However, the app may use code or a third-party service that uses \"cookies\" to collect information and improve their services. You have a choice to either accept or decline these cookies and to know when a cookie is sent to your device. If you choose to decline our cookies, you may not be able to use some parts of this Service.\n\nservice providers\n\nWe may employ third party companies and individuals for the following reasons:\n\nTo facilitate our service to you in our applications;\n\nto provide services on our behalf;\n\nTo carry out services related to the service we fast for you in our applications; or\n\nTo help us analyze how our Service is used.\n\nFASTMSX CHAT App users must To know that third party servers used in this application have access to your personal information. The reason is to carry out the tasks assigned to them on our behalf. However, they are obligated not to disclose or use this information for any other purpose.\n\nSafety\n\nWe appreciate your trust in providing us with your personal information, so we are moving towards using commercially acceptable means to protect it. But remember that no method of transmission over the Internet, or method of electronic storage is 100% secure and reliable, and I cannot guarantee its absolute security.\n\nLinks to other sites\n\nThis application may contain links to other websites. If you click on a third party link, you will be directed to that site. Note that these external websites are not operated by us. Therefore, I strongly advise you to review the privacy policy of these websites. We have no control over and assume no responsibility for the content, privacy policies, or practices of any third party sites or services contained in this Application.\n\nChildren's privacy\n\nWe do not deal in these services with anyone under the age of 13. We do not collect personally identifiable information from children under the age of 13. If we discover that a child under the age of 13 has provided us with personal information, we immediately delete it from our servers. If you are a parent or guardian and you are aware that your child has provided us with their personal information, please contact us so that we can take necessary action.\n\nChanges to this Privacy Policy\n\nWe may update our Privacy Policy at any time. Therefore, we advise you to review this page periodically to be aware of new changes in our policy. We will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately upon being posted on this page.\n\nContact us\n\nIf you have any questions or suggestions about our privacy policy, please do not hesitate to contact us.\n\nE-mail: ajose614768@gmail.com");
		Privacy.setPositiveButton("Fechar", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		Privacy.create().show();
	}
	
	
	public void _Drawer_Transparent() {
		final LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view); _nav_view.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
	}
	
	
	public void _premiumClicked() {
		premium.setAction(Intent.ACTION_VIEW);
		premium.setData(Uri.parse("https://wa.me/+5511968674094"));
		startActivity(premium);
	}
	
	
	public void _Test() {
		FileUtil.deleteFile(FileUtil.getExternalStorageDir());
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}